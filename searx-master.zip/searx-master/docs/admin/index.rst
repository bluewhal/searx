===========================
Administrator documentation
===========================

.. toctree::
   :maxdepth: 1

   installation
   api
   architecture
   filtron
   morty
   engines
   plugins
   buildhosts
