==================
User documentation
==================

.. toctree::
   :maxdepth: 1

   search_syntax
   own-instance
